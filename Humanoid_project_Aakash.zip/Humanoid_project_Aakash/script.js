let btn = document.querySelector("#mode");
let mode = "Light Mode";

btn.addEventListener("click",()=>{
    
    if(mode === "Light Mode")
    {
        mode = "Dark Mode";
        document.querySelector("body").style.backgroundColor = "black"
        document.querySelector("h2").style.color= "white"
    }
    else
    {
        mode = "Light Mode";
        document.querySelector("body").style.backgroundColor = "white"
        document.querySelector("h2").style.color= "black"
    }
    console.log(mode);
    console.log("Mode Changed");
});
document.getElementById("upload").addEventListener("click", function () {
    const link = document.getElementById("generate").value;
    

})