import { useState, useEffect } from 'react';
import './Tutor.css';

const Tutor = () => {
  const [status, setStatus] = useState('Idle...');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speakerTranscript, setSpeakerTranscript] = useState('Transcript will appear here...');
  const [listenerTranscript, setListenerTranscript] = useState('Listener\'s input will appear here...');
  const [currentTopic, setCurrentTopic] = useState('Introduction to AI');

  const [isSynthSupported, setIsSynthSupported] = useState(false);
  const [isRecognitionSupported, setIsRecognitionSupported] = useState(false);

  let synth;
  let recognition;

  // Check browser support on component mount
  useEffect(() => {
    if ('speechSynthesis' in window) {
      synth = window.speechSynthesis;
      setIsSynthSupported(true);
    } else {
      console.error('SpeechSynthesis API not supported in this browser.');
    }

    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      setIsRecognitionSupported(true);
    } else {
      console.error('SpeechRecognition API not supported in this browser.');
    }
  }, []);

  const toggleSpeaking = () => {
    if (!isSpeaking) {
      startSpeaking();
    } else {
      stopSpeaking();
    }
  };

  const startSpeaking = () => {
    if (!isSynthSupported) {
      alert('Speech synthesis is not supported in your browser.');
      return;
    }
    setIsSpeaking(true);
    setStatus('Speaking...');
    const utterance = new SpeechSynthesisUtterance('Hello! How can I assist you today?');
    synth.speak(utterance);
    setSpeakerTranscript('Hello! How can I assist you today?');
    utterance.onend = stopSpeaking;
  };

  const stopSpeaking = () => {
    setIsSpeaking(false);
    setStatus('Idle...');
  };

  const startListening = () => {
    if (!isRecognitionSupported) {
      alert('Speech recognition is not supported in your browser.');
      return;
    }
    setStatus('Listening...');
    recognition.start();
  };

  if (recognition) {
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setListenerTranscript(transcript);
      stopListening();
      speakResponse(transcript);
    };
  }

  const stopListening = () => {
    setStatus('Idle...');
  };

  const speakResponse = (input) => {
    if (!isSynthSupported) return;
    const utterance = new SpeechSynthesisUtterance(`You said: ${input}`);
    synth.speak(utterance);
  };

  const updateTopic = (e) => {
    e.preventDefault();
    const newTopic = e.target.elements.topic.value;
    if (newTopic.trim()) {
      setCurrentTopic(newTopic);
    }
    e.target.reset();
  };

  return (
    <div className="container">
      <div className="header">
        <h1>Interactive Tutor</h1>
        <p>Your AI Learning Companion</p>
      </div>
      <div className="display-container">
        {status === 'Listening...' && <div className="rotating-sphere" />}
        {status !== 'Listening...' && (
          <div className="display">
            <img src="https://via.placeholder.com/300" alt="Dynamic Element" />
          </div>
        )}
      </div>
      <div className="controls">
        <button className="toggle-btn" onClick={toggleSpeaking}>
          {isSpeaking ? 'Stop Speaking' : 'Start Speaking'}
        </button>
        <button className="listen-btn" onClick={startListening}>Listen</button>
        <form className="topic-input" onSubmit={updateTopic}>
          <input type="text" name="topic" placeholder="Enter current topic" />
          <button type="submit">Update Topic</button>
        </form>
      </div>
      <div className="status">{status}</div>
      <div className="transcript">
        <h3>Speaker Transcript:</h3>
        <p>{speakerTranscript}</p>
      </div>
      <div className="listener-transcript">
        <h3>Listener Transcript:</h3>
        <p>{listenerTranscript}</p>
      </div>
      <div className="lesson-plan">
        <h3>Lesson Plan:</h3>
        <p>Current Topic: {currentTopic}</p>
      </div>
    </div>
  );
};

export default Tutor;
